# Indian Stock Market AI Predictor

### Setup

1. Clone or download the project
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Run the dashboard:
```bash
streamlit run app.py
```

Enter stock symbols like `TCS.NS`, `RELIANCE.NS`, `INFY.NS` etc.