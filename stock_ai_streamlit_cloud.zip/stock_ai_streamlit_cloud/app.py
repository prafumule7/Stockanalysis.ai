import streamlit as st
from data_fetch import get_stock_data
from indicators import add_indicators
from model_train import train_model
from predict import get_signal

st.set_page_config(layout="wide")
st.title("📈 Indian Stock Market AI - Price Movement Prediction")

symbol = st.text_input("Enter NSE Symbol (e.g., TCS.NS, RELIANCE.NS):", "TCS.NS")

df = get_stock_data(symbol)
df = add_indicators(df)
model, df = train_model(df)

st.subheader("Latest Prediction")
st.write(f"**Signal:** {get_signal(df['prediction'].iloc[-1])}")
st.write(f"**Close Price:** ₹{df['Close'].iloc[-1]:.2f}")

st.subheader("Historical Close Price & Predictions")
st.line_chart(df[['Close', 'prediction']])